#include <iostream>
using namespace std;


int main(){
    int day;
    cout << "Введите номер дня в году: ";
    cin >> day;
    cout << "Номер дня недели: " << ((day+4)%7)+1;
    return 0;
}