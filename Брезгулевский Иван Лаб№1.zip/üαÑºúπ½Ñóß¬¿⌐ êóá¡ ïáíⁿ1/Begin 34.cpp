#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float X, Y, A, B, Sx, Sy, Dif;
    cout << "Введите X кг шоколадных конфет: ";
    cin >> X;
    cout << "Введите стоимость шоколадных конфет: ";
    cin >> A;
    cout << "Введите Y кг ирисок: ";
    cin >> Y;
    cout << "Введите стоимость ирисок: ";
    cin >> B;
    Sx = A/X;
    Sy = B/Y;
    Dif = Sx/Sy;
    cout << "Цена 1 кг шоколадных конфет: " << Sx << "\n";
    cout << "Цена 1 кг ирисок: " << Sy << "\n"; 
    cout << "Во столько раз шоколадные конфеты дороже ирисок: " << Dif;
    return 0;
}