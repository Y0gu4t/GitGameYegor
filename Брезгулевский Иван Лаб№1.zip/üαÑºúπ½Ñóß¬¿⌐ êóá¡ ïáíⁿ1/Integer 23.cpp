#include <iostream>
using namespace std;


int main(){
    int seconds, minutes;
    cout << "Введите количество секунд: ";
    cin >> seconds;
    minutes = seconds/60;
    cout << "Прошло минут с последнего часа: " << minutes%60;
    return 0;
}