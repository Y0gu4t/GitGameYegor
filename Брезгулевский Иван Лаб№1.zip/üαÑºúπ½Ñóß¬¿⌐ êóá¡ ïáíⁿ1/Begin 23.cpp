#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float a, b, c, t;
    cout << "Введите A: ";
    cin >> a;
    cout << "Введите B: ";
    cin >> b;
    cout << "Введите C: ";
    cin >> c;
    t = b; b = a; a = c; c = t;
    cout << "Новые значения A, B, C: " << a << " " << b << " " << c;
    return 0;
}
