#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float a, V, S;
    cout << "Введите a: ";
    cin >> a;
    V = pow(a,3);
    S = 6*pow(a,2);
    cout << "V= " << V << "\n";
    cout << "S= " << S;
    return 0;
}