#include <iostream>
using namespace std;


int main(){
    int seconds;
    cout << "Введите количество секунд: ";
    cin >> seconds;
    cout << "Прошло секунд с последнего часа: " << seconds%3600;
    return 0;
}